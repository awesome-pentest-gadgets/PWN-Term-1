package hilled.pwnterm.framework.reflection;

/**
 * @author kiva
 */
public class ReflectionException extends RuntimeException {
  ReflectionException(Throwable cause) {
    super(cause);
  }
}
