package hilled.pwnterm.framework.reflection;

/**
 * class representing null pointer.
 *
 * @author kiva
 */
public class NullPointer {
}