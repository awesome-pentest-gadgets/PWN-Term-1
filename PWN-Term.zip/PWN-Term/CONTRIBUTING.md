# Contributing

# How to

NeoTerm is a free software, so any contributions and any contribution types are welcomed!

