package hilled.pwnterm;

import hilled.pwnterm.xorg.NeoXorgViewClient;

/**
 * @author kiva
 */

public class NeoAudioThread extends AudioThread {
  public NeoAudioThread(NeoXorgViewClient client) {
    super(client);
  }
}
